#read_camera

TODO:

need to add node to calibration camera!

calibration file is in folder "xml"
