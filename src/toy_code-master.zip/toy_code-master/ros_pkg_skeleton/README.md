a code skeleton
