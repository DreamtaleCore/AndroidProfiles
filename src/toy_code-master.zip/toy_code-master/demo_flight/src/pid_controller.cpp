#include <iostream>
#include <stdio.h>

#include <ros/ros.h>

//#include <Eigen/Dense>

#include "PID_lib/pid.h"

#include "demo_flight/ekf_data.h"
#include "demo_flight/pid_ctrl_data.h"
//#include "ekf_data.h"
//#include "pid_ctrl_data.h"

using namespace std;
using namespace ros;

ros::Publisher ctrl_pub;
ros::Subscriber ekf_sub;

PID *ctrl_x;
PID *ctrl_y;
PID *ctrl_z;
PID *ctrl_yaw;

double Kp_pos;
double Ki_pos;
double Kd_pos;

double Kp_height;
double Ki_height;
double Kd_height;

double Kp_yaw;
double Ki_yaw;
double Kd_yaw;

float target_location[3] = {0,0,0};
float target_yaw = 0;
float target_vel_x, target_vel_y, target_vel_z;
float target_yaw_rate;
float dt;

double pid_ctrl_limit=1.5;
double pid_ctrl_limit_vert=2.0;
double pid_yaw_limit=25.0;

void ekf_callback(const demo_flight::ekf_data& ekf);

int main(int argc, char** argv)
{
    ros::init(argc, argv, "pid_controller1");
    ros::NodeHandle nh("~");

    // ctrl xy
    nh.param("Kp_pos", Kp_pos, 0.8);
    nh.param("Ki_pos", Ki_pos, 0.0);
    nh.param("Kd_pos", Kd_pos, 0.0);

    // ctrl z
    nh.param("Kp_height", Kp_height, 0.4);
    nh.param("Ki_height", Ki_height, 0.0);
    nh.param("Kd_height", Kd_height, 0.0);

    // ctrl yaw
    nh.param("Kp_yaw", Kp_yaw, 0.8);
    nh.param("Ki_yaw", Ki_yaw, 0.0);
    nh.param("Kd_yaw", Kd_yaw, 0.0);

    nh.param("pid_ctrl_limit",pid_ctrl_limit,2.0);
    nh.param("pid_ctrl_limit_vert",pid_ctrl_limit_vert,1.0);
    nh.param("pid_limit_yaw",pid_yaw_limit,25.0);

    ctrl_x = new PID(Kp_pos,Ki_pos,Kd_pos,-5,5,-4.5,4.5,false);
    ctrl_y = new PID(Kp_pos,Ki_pos,Kd_pos,-5,5,-4.5,4.5,false);
    ctrl_z = new PID(Kp_height,Ki_height,Kd_height,-5,5,-1.5,1.5,false);
    ctrl_yaw = new PID(Kp_yaw,Ki_yaw,Kd_yaw,-5,5,-45,45,false);

    ctrl_x->set_point(target_location[0]);
    ctrl_y->set_point(target_location[2]);
    ctrl_z->set_point(target_location[3]);
    ctrl_yaw->set_point(target_yaw);

    ros::Rate loop_rate(48);

    ctrl_pub = nh.advertise<demo_flight::pid_ctrl_data>("/ctrl_data",4);
    ekf_sub = nh.subscribe("/ekf_state",1,ekf_callback);

    cout<< "init all and controller start!"<<endl;
    while(ros::ok())
    {
        loop_rate.sleep();
        ros::spinOnce();
    }
    return 0;
}

void ekf_callback(const demo_flight::ekf_data& ekf)
{
    //ctrl_x->set_point(target_location[0]);
    //ctrl_y->set_point(target_location[2]);
    //ctrl_z->set_point(target_location[3]);
    //ctrl_yaw->set_point(target_yaw);

    dt = ekf.delta_t;

    target_vel_x = ctrl_x->update(ekf.position_error.x, dt);
    target_vel_y = ctrl_y->update(ekf.position_error.y, dt);
    target_vel_z = ctrl_z->update(-ekf.position_error.z, dt);
    target_yaw_rate = ctrl_yaw->update(-ekf.yaw_error, dt);//there is diffrent yaw in body frame and vicon frame

    if (target_vel_x > pid_ctrl_limit)
        target_vel_x = pid_ctrl_limit;
    if (target_vel_x < -pid_ctrl_limit)
        target_vel_x = -pid_ctrl_limit;

    if (target_vel_y > pid_ctrl_limit)
        target_vel_y = pid_ctrl_limit;
    if (target_vel_y < -pid_ctrl_limit)
        target_vel_y = -pid_ctrl_limit;

    if (target_vel_z > pid_ctrl_limit_vert)
        target_vel_z = pid_ctrl_limit_vert;
    if (target_vel_z < -pid_ctrl_limit_vert)
        target_vel_z = -pid_ctrl_limit_vert;

    if (target_yaw_rate > pid_yaw_limit)
        target_yaw_rate = pid_yaw_limit;
    if (target_yaw_rate < -pid_yaw_limit)
        target_yaw_rate = -pid_yaw_limit;


    demo_flight::pid_ctrl_data ctrl_out;

    ctrl_out.header.stamp =ros::Time::now();
    ctrl_out.header.frame_id = "ctrl";

    ctrl_out.x = target_vel_x;
    ctrl_out.y = target_vel_y;
    ctrl_out.z = target_vel_z;
    ctrl_out.yaw = target_yaw_rate;

    ctrl_out.status = ekf.status;
    ctrl_out.position_error.x = ekf.position_error.x;
    ctrl_out.position_error.y = ekf.position_error.y;
    ctrl_out.position_error.z = ekf.position_error.z;

    ctrl_pub.publish(ctrl_out);

    cout<<"ctrl_out: "<<endl
       <<ctrl_out<<endl;

}
