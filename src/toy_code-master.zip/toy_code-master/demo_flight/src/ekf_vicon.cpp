#include <iostream>
#include <stdio.h>

#include <ros/ros.h>

#include "geometry_msgs/TransformStamped.h"
#include "geometry_msgs/Point.h"
//#include "TransformStamped.h"
#include "demo_flight/ekf_data.h"
#include "demo_flight/move_target.h"
//#include "move_target.h"
//#include "ekf_data.h"

#include "math_lib/math_lib.h"

using namespace std;
using namespace ros;

ros::Subscriber vicon_debug_sub;
ros::Publisher ekf_pub;

vector3f T_v;
vector3f T_tv;
vector4f q_vb;
matrix3f R_vb,R_bv;
matrix3f R_m100_to_b;

vector3f T_v_stick, delta_T_v;
vector3f delta_T_b, delta_T_m100;

float yaw_target = -90.0f/57.29f;
float yaw_delta;
float roll_stick;

int status=0;

void callback(const geometry_msgs::TransformStamped& vicon_data, const demo_flight::move_target& target_point);
void wand_callback(const geometry_msgs::TransformStamped& vicon_data);

int main(int argc, char** argv)
{
    ros::init(argc,argv,"vicon_ekf1");
    ros::NodeHandle nh;

    T_tv[0]=0;
    T_tv[1]=0;
    T_tv[2]=0;

    T_v[0]=0;
    T_v[1]=0;
    T_v[2]=0;

    matrix3f_set_value(R_m100_to_b,
                       1, 0, 0,
                       0, -1, 0,
                       0, 0, -1);

    ekf_pub = nh.advertise<demo_flight::ekf_data>("ekf_state",4);

    message_filters::Subscriber<geometry_msgs::TransformStamped> vicon_sub(nh, "/vicon/M100_1/M100_1", 1);
    message_filters::Subscriber<demo_flight::move_target> target_sub(nh, "/move_target", 1);

    typedef message_filters::sync_policies::ApproximateTime<geometry_msgs::TransformStamped, demo_flight::move_target> SyncPolicy;
    message_filters::Synchronizer<SyncPolicy> sync(SyncPolicy(20), vicon_sub, target_sub);

    sync.registerCallback(boost::bind(&callback, _1,_2));

    cout<<"start and wait vicon data."<<endl;

    ros::spin();
    return 0;
}


void wand_callback(const geometry_msgs::TransformStamped& vicon_data)
{

    T_v_stick[0] = vicon_data.transform.translation.x;
    T_v_stick[1] = vicon_data.transform.translation.y;
    T_v_stick[2] = vicon_data.transform.translation.z;

    delta_T_v[0] = T_v_stick[0]-T_v[0];
    delta_T_v[1] = T_v_stick[1]-T_v[1];
    delta_T_v[2] = T_v_stick[2]-T_v[2];

    matrix3f_multi_vector3f(delta_T_b,R_bv,delta_T_v);

    cout<<endl<<delta_T_b[0]*100
       <<endl<<delta_T_b[1]*100
      <<endl<<delta_T_b[2]*100<<endl;

    matrix3f_multi_vector3f(delta_T_m100,R_m100_to_b,delta_T_b);

    cout<<endl<<delta_T_m100[0]*100
       <<endl<<delta_T_m100[1]*100
      <<endl<<delta_T_m100[2]*100<<endl;

}

void callback(const geometry_msgs::TransformStamped& vicon_data, const demo_flight::move_target& target_point)
{
    status = target_point.stick_state;

    T_tv[0]=target_point.x;
    T_tv[1]=target_point.y;
    T_tv[2]=target_point.z;

    T_v[0] = vicon_data.transform.translation.x;
    T_v[1] = vicon_data.transform.translation.y;
    T_v[2] = vicon_data.transform.translation.z;

    cout<<"vicon data:"<<endl;
    cout<<"translation:"<<endl;
    cout<<T_v[0]<<" "<<T_v[1]<<" "<<T_v[2]<<endl;

    q_vb[0] = vicon_data.transform.rotation.w;
    q_vb[1] = vicon_data.transform.rotation.x;
    q_vb[2] = vicon_data.transform.rotation.y;
    q_vb[3] = vicon_data.transform.rotation.z;
    cout<<"rotation:"<<" "<<q_vb[0]<<" "<<q_vb[1]<<" "<<q_vb[2]<<" "<<q_vb[3]<<endl;

    quat_to_DCM(R_vb, q_vb);
    get_matrix3f_transpose(R_bv,R_vb);

    vector3f location_error_v, location_error_b,location_error_m100;

    location_error_v[0]=T_v[0]-T_tv[0];
    location_error_v[1]=T_v[1]-T_tv[1];
    location_error_v[2]=T_v[2]-T_tv[2];

    matrix3f_multi_vector3f(location_error_b,R_bv,location_error_v);

    matrix3f_multi_vector3f(location_error_m100,R_m100_to_b,location_error_b);


    float yaw,pitch,roll;
    quat_to_eular(&yaw,&pitch,&roll,q_vb);
    cout<<"yaw: "<<yaw*57.29<<endl;

    yaw_delta = yaw-yaw_target;
    cout<<"yaw_delta: "<<yaw_delta*57.29<<endl<<endl;

    demo_flight::ekf_data ekf_out;

    ekf_out.position_error.x = location_error_m100[0];
    ekf_out.position_error.y = location_error_m100[1];
    ekf_out.position_error.z = location_error_m100[2];

    //ekf_out.position_target

    ekf_out.yaw_error = yaw_delta;
    ekf_out.yaw_correct = yaw;

    ekf_out.delta_t = 0.02f;

    ekf_out.status=status;

    ekf_pub.publish(ekf_out);

    cout<<"ekf_out "<<endl<<ekf_out<<endl;

}
